from django.contrib import admin
from .models import PaymentHistory

# Register your models here.

admin.site.register(PaymentHistory)